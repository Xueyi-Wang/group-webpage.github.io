---
# Generate Decap CMS
type: decap_cms
private: true
outputs:
  - decap_cms_config
  - HTML
---
